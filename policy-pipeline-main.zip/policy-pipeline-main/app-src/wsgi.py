#
# Copyright (c) 2024 Red Hat Training <training@redhat.com>
#
# All rights reserved.
# No warranty, explicit or implied, provided.

from io import BytesIO
from flask import Flask, request, send_file
from PIL import Image, ImageDraw, ImageFont

application = Flask(__name__)


@application.route("/")
def root():
    return """<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Labelling the Organization Logo</title>
  </head>
  <body>
      <form action="/label" method="GET">
         <label for="label">Your label:</label>
         <input type="text" id="label" name="label" required />
         <input type="submit"/>
      </form>
  </body>
</html>"""


@application.route("/label")
def label():
    text = request.args.get("label")
    im = Image.open("org-logo.jpg")
    width, height = im.size
    draw = ImageDraw.Draw(im)
    for sz in range(120, 10, -10):
        font = ImageFont.truetype("DejaVuSans.ttf", sz)
        textwidth = draw.textlength(text, font)
        if textwidth < width:
            textheight = sz
            break

    # Calculate the x,y coordinates of the text
    margin = 10
    x = width - textwidth - margin
    y = height - textheight - margin

    # Draw the text in the bottom right corner
    draw.text((x + 2, y + 2), text, font=font, fill=(0, 0, 0, 255))
    draw.text((x - 2, y - 2), text, font=font, fill=(0, 0, 0, 255))
    draw.text((x, y), text, font=font)

    img_io = BytesIO()
    im.save(img_io, "JPEG", quality=70)
    img_io.seek(0)
    return send_file(img_io, mimetype="image/jpeg")


@application.route("/health")
def health():
    return "ok"
