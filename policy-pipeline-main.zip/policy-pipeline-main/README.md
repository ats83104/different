# Labelling the Organization Logo

This application enables you to add a label to our organization logo.

The application Python code is available in the `app-src/` directory.
The resource file to deploy the application in Red Hat OpenShift is available in the `resources/` directory.


## Testing the Application Locally

podman build -t org-logo .
podman run --rm -p 8080:8080 localhost/org-logo
